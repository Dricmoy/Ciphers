I did not collaborate with anyone for this assignment

Resources Consulted:
https://crypto.interactive-maths.com/rail-fence-cipher.html - to visualize the cypher